const FRAME_RATE = 30;
var clicks = 0;

function setup() {
    createCanvas(400,400);
    colorMode(RGB, 360, 100, 100, 1);
}

function draw() {
  background(50, 75, 50);
  //prints every 2 seconds
  if ((frameCount % (FRAME_RATE * 2)==0)&&(frameCount<=360)){
    print(frameCount);
  }
  //starts face
  animS.arc('a1', 60, 200, 200, 100, 100,0,PI);
  describe('Currently drawing:mouth!', LABEL);
  if (frameCount >= FRAME_RATE * 2){
  animS.ellipse('e1', 60, 150, 100, 50, 100);
  animS.ellipse('e2', 60, 250, 100, 50, 100);
  describe('Currently drawing:eyes!', LABEL);
  }
  //starts drawing text
  if (frameCount >= FRAME_RATE * 4){
  animS.ellipse('s1', 60, 130, 310, 200, 100);
  describe('Currently drawing:speech bubble!', LABEL);
  }
  push();
  strokeWeight(3);
  if (frameCount >= FRAME_RATE * 6){
  animS.line('h1', 60, 100, 300, 100, 330);
  animS.line('h2', 60, 100, 315, 120, 315);
  animS.line('h3', 60, 120, 300, 120, 330);
  describe('Currently drawing:H!', LABEL);
  }
  if (frameCount >= FRAME_RATE * 8){
  animS.circle('i1', 60, 140, 305, 3);
  animS.line('i2', 60, 140, 315, 140, 330);
  describe('Currently drawing:I!', LABEL);
  }
  if (frameCount >= FRAME_RATE * 10){
  animS.circle('!1', 60, 160, 330, 3);
  animS.line('!2', 60, 160, 300, 160, 320);
  describe('Currently drawing:!!', LABEL);
  }
  pop();
  //updates description
  if (frameCount >= FRAME_RATE *12){
    describe('Finished drawing! Click to watch everything drawn at once!', LABEL);
  }
  if (frameCount>=2000&&clicks==0){
    describe('Hey...are you there? You can click the screen now :)', LABEL);
}
  if (frameCount>=4000&&clicks==0){
    describe('YOU FOUND A SECRET!!!! ...too bad you don\'t win anything ¯\\_(ツ)_/¯', LABEL);
  }
}
function mouseClicked() {
  if(frameCount>360){
  animS.reset();
  clicks++;
  print(clicks);
  }
}
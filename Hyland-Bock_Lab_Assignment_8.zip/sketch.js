let beacon;
let hand;
let beaconstate=0;
let mysound;
let cooldown=0;

function preload(){
  beacon=loadImage("beacon.jfif");
  hand=loadImage("hand.png");
  mysound=loadSound("sfx.mp3");
}

function setup() {
  createCanvas(600, 600);
  frameRate(10);
  print(beacon.width);
  print(beacon.height);
  describe('press b for really loud sound after 5 seconds, click to stop all sound',LABEL);
  //describe('SOUND WARNING, DONT HOVER OVER THE BEACON FOR MORE THAN A SECOND',LABEL);
  //it kept playing the sfx so it was really loud, but i solved the issue with a cooldown timer
}

function draw() {
  background(220);
  push();
  tint(255,20);
  image(beacon,0,0,300,200);
  pop();
  text(cooldown,500,500);
  cooldown--;
  if(cooldown<=0){
    cooldown=0;
  }
  if(mouseX<300&&mouseY<200){
    tint(255,255);
    image(beacon,0,0,400,266);
    beaconstate=1;
    textSize(50);
    fill(255,0,0);
    textFont('Times New Roman');
    text('A NEW HAND TOUCHES THE BEACON',0,400,500,200);
    text('A NEW HAND TOUCHES THE BEACON',400,50,200,500);
    if(cooldown==0){
      mysound.play();
      cooldown=100;
    }
     }
  image(hand,mouseX-25,mouseY-25,50,50);
}
function mousePressed(){
    mysound.stop(0);
    cooldown=0;
  //idk why this doesnt work :(
  //nvm i had it in the draw function it works now
  }
function keyTyped(){
  if (key==='b')
    {
      text('SOUND WARNING IN 5 SECONDS',400,400);
      for(let i=0;i<100;i++){        
      mysound.play(5);
      }
 
    }
}
//none of the example files loaded the images for me,i kept getting cross origin errors:(
//i might have cheated with transparency because i didnt understand the book?
//also this entire thing is a joke based on skyrim
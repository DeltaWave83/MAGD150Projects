var x=[];
var y=[];
var size=[];
let angle=0;

function setup() {
  createCanvas(400, 400);
  for (var i = 0; i < 500; i++) {
	x[i] = random(-200,200); 
    y[i] = random(0,-5000);
    size[i] = random(0.3,2);
  }
}

function returnavalue(){
  var randomnumber=(random(0,9999));
  return randomnumber;
}

function drop(x,y,size){
  angleMode(RADIANS);
  push();
  scale(size);
  translate(x,y);
  //i swapped scale and translate to have scale first and got a 3d effect and im really happy with this
  fill(0,50,200);
  arc(200,200,50,50,-0.5,PI+0.5,OPEN);
  line(178,190,200,130);
  line(200,130,222,190);
  beginShape();
  fill(0,50,200);
  vertex(178,190);
  vertex(200,130);
  vertex(222,190);
  endShape();
  pop();
}

function draw() {
  background(220);
  push();
  angleMode(DEGREES);
  translate(200,200);
  rotate(angle);
  fill(255,215,0);
  ellipse(170,170,50);
  pop();
  angle++;
  if(angle==360){
    angle=0;
    var getrandom=returnavalue();
    print(int(getrandom));
  }
  for (var i = 0; i < x.length; i++) {

		
		y[i] +=2;

		
		drop(x[i],y[i],size[i]);
	}

describe('A very rainy day, featuring the sun moving at 1 million times speed. The console prints a random number everytime the sun sets in the...east? Wait, is this a different planet??',LABEL);
}